# PROMPT MESTRE — HelpMyDesk: refinamento autoral da identidade visual e reconstrução da UI desktop

Você está trabalhando dentro do repositório **real** `JamesonHenrique/helpmydesk`. Sua tarefa é IMPLEMENTAR uma evolução profunda da interface visual e do sistema de identidade. Não quero apenas análise, auditoria, relatório de recomendações, plano teórico, checklist ou mockup estático. **Faça as mudanças de código necessárias, valide-as e entregue o aplicativo visualmente refinado.**

Leia integralmente antes de editar:
- `AGENTS.md` e `.specify/memory/constitution.md`;
- `.claude/skills/helpmydesk-visual-identity/SKILL.md`;
- `branding/tokens.json`, `branding/tokens.css`, `branding/manifest-assets.json`;
- `apps/desktop/ui/src/styles.css`, `apps/desktop/ui/src/app/app.html`, `apps/desktop/ui/src/app/app.css`;
- todas as telas em `apps/desktop/ui/src/app/pages/` e `apps/desktop/ui/src/app/components/`;
- os testes relacionados à UI, `README.md` e as specs relevantes para os fluxos que a UI apresenta;
- os documentos `IDENTIDADE-VISUAL-V2.md`, `COMPONENTES-E-TELAS.md` e `CRITERIOS-DE-ACEITACAO.md` deste kit;
- `assets/references/prancha-direcao-visual.png` (referência de arte; não copiar texto malformado da imagem);
- `assets/illustrations/assistente-oficina.png` (ilustração de marca a usar com parcimônia).

Se estes documentos foram anexados fora do workspace, localize o kit disponibilizado pelo usuário. Se não estiver no workspace, não pare apenas por isso: aplique a direção completa deste prompt e continue usando o repositório como fonte de verdade. Faça inspeção primeiro e implemente em seguida.

## MISSÃO

Elevar a UI atual para **“Oficina editorial de precisão”**: um aplicativo desktop com personalidade, forte hierarquia, composição intencional, uma linguagem gráfica própria e uma experiência calorosa para pessoas não técnicas. Deve parecer software autoral que só poderia ser HelpMyDesk — não dashboard de SaaS copiado, template de admin, produto roxo de IA, formulário branco com cards iguais ou uma landing page dentro de uma janela.

Preservar o DNA existente: papel quente, carvão, vermelho-sinal, coral e verde-lima de verificação; tagline “Seu computador, sem mistério.”; textura editorial discreta; explicação honesta, ação com consentimento e verificação real. Refinar essa identidade, não apagá-la. Caso introduza a tinta técnica verde-petróleo sugerida (`#496965` no tema claro e uma variante aprovada para o escuro), adicione tokens semânticos e mantenha os três pontos sincronizados. Não espalhe cores novas fora do sistema de tokens.

## REGRAS DE EXECUÇÃO — NÃO ENCERRAR DEPOIS DA AUDITORIA

1. Faça uma leitura breve e dirigida para confirmar estrutura, estado de cada tela, arquitetura e testes; em seguida passe para implementação concreta.
2. Crie um plano interno em etapas e execute-o; não espere nova autorização para tarefas visuais normais. Pergunte só se encontrar decisão de produto irreversível ou ambiguidade que bloqueie o funcionamento.
3. Não termine com “aqui estão as recomendações”. Edite arquivos reais do app e seus assets, página por página.
4. Não tente reescrever o núcleo Rust ou alterar comportamento de diagnóstico para “parecer melhor”. O escopo é UI, estilos, assets e documentação da identidade. Só mude comportamento visual estritamente necessário, mantendo os contratos existentes.
5. Não adicione dependências visualmente pesadas, fontes remotas, animações contínuas ou bibliotecas de ícones sem necessidade e justificativa explícita.
6. Antes de encerrar, execute as verificações disponíveis e corrija os erros encontrados. Se um comando não puder rodar por falta de dependência, ferramenta ou ambiente, diga exatamente qual e não declare que passou.
7. Não comite nem faça push sem pedido explícito. Não apague alterações preexistentes do usuário.

## PRINCÍPIO DE DESIGN CENTRAL

**“Uma oficina calma, editorial e técnica que explica antes de tocar.”** O app deve transmitir curiosidade, competência, cuidado, transparência e controle do usuário. Diferenciar por layout, composição e semântica gráfica — não por ruído visual.

### Paleta e tokens

- Base: `--bg #F3F0E6`, `--surface #FFFCF5`, `--surface-raised #FFFEFA`, `--fg #22282D`, `--muted #596267`, `--line #C8C5BA`.
- Ação: `--accent #B73825` no tema claro (manter a variante do tema escuro conforme tokens atuais); `--coral #FF6C4D` como detalhe de marca, não texto pequeno sobre papel.
- Ponto de verificação: `--checkpoint #D8F16A`, reservado a seleção/foco/verificação real. Não usar como fundo dominante ou decoração sem propósito.
- Estados: manter tokens `--ok`, `--warn`, `--bad`, `--focus` e variantes dark já definidas; sempre ícone/rótulo além da cor.
- Opcional: `--technical-ink` (proposta `#496965`) e `--technical-soft` (proposta `#DDE8E3`) somente se melhorar diagramas e hierarquia. Verificar contraste e definir variantes dark apropriadas. Não usar tintas novas diretamente nos componentes.
- Se houver mudança de valor ou token, atualizar na mesma alteração `apps/desktop/ui/src/styles.css` (fonte operacional atual), `branding/tokens.css`, `branding/tokens.json`, `branding/manifest-assets.json` se aplicável e esta skill visual `.claude/skills/helpmydesk-visual-identity/SKILL.md`. Essas fontes devem ficar sincronizadas.
- Preservar o controle dinâmico de escala de texto: `app.ts` escreve no `documentElement`; jamais fixar `html { font-size }` ignorando `var(--font-size, 1.0625rem)`.
- Tema escuro completo, incluindo inputs, bordas, hover, seleção, foco, diagramas e todos os estados. Preservar `prefers-color-scheme` e `data-theme`.

### Tipografia

Manter fontes de sistema e monoespaçada existentes para operação offline e velocidade. Criar personalidade por hierarquia: títulos de grande escala e peso forte, tracking sutilmente negativo, rótulos técnicos pequenos porém legíveis e números/índices monoespaçados. Escala sugerida: display `clamp(2rem, 3.2vw, 3.25rem)`, título de tela `clamp(1.7rem, 2.6vw, 2.35rem)`, seção ~`1.25rem`, corpo ao menos `1rem`, auxiliar sem cair em texto ilegível. Não introduza fonte remota.

### Materiais gráficos

Usar: trilhas de diagnóstico como desenho auxiliar de baixa opacidade; marcas de inspeção numeradas; selos pequenos reservados a resultados que realmente foram conferidos; linhas, recortes e camadas de papel; ilustração do assistente-oficina em poucos pontos. Nada de gradiente violeta/azul, ícones emoji, gráficos fake, bento cards idênticos em todas as páginas, glassmorphism ou sombra difusa de dashboard SaaS.

A prancha gerada é só referência de atmosfera/composição. Nunca use-a como interface pronta, imagem de fundo integral ou substituto de HTML acessível. O arquivo do mascote é ilustrativo; utilizar preferencialmente em Início e onboarding. Não inserir em todas as páginas e não deixar que ocupe mais espaço que o objetivo do usuário.

## ARQUITETURA VISUAL DESKTOP

Refaça o shell global como **sidebar persistente + workspace principal**:

- Sidebar desktop ~224–248 px com símbolo/wordmark, navegação agrupada e área de rodapé tranquila.
- Grupos: **Atendimento** (Início, Histórico), **Computador** (Meu computador), **Preferências** (Configurações, Ajuda). Usar as rotas atuais e manter seleção real com `routerLinkActive`/`ariaCurrentWhenActive`.
- O item ativo pode usar superfície carvão, acento vermelho-sinal e marcador lima mínimo. Não transformar cada item em cartão.
- Workspace mais amplo que o atual `max-width: 52rem`; criar limite de leitura dentro das páginas que precisam de prosa, mas permitir layouts com colunas no desktop.
- Cabeçalho da página: título, subtítulo e breadcrumb discreto quando útil. Evitar a mesma caixa/padrão de header em toda página.
- Estado do protótipo permanece claro e honesto, sem tomar uma faixa gigante da tela.
- Responsividade: desktop amplo, largura média e janela estreita Tauri. Sidebar deve compactar ou virar navegação adaptada sem esconder nomes acessíveis nem causar overflow.
- Conservar suporte a teclado, skip link, foco, `aria-live`, `role=alert`, labels, semântica e redução de movimento.

Criar um sistema de superfícies variado, conforme objetivo: panel editorial, ficha técnica, tile de escolha, faixa de segurança, timeline/lista e prévia de relatório. Pare com o uso de `.card` como formato universal. Evite cartões aninhados sem motivo.

## TELAS QUE DEVEM SER IMPLEMENTADAS

### 1. Início — `pages/home.ts`

- Hero memorável e assimétrico com grande mensagem, texto acolhedor e ilustração do assistente-oficina em espaço reservado. O conteúdo precisa ser o protagonista.
- O campo de texto é um caminho central quando a IA está conectada. Manter preview exato do que será enviado, limites, busy state, perguntas, erros e disabled real.
- Quando a IA estiver desligada, não deixar um input desabilitado dominar a tela: explicar sucintamente e valorizar visualmente o modo básico.
- Transformar as cinco famílias de problema existentes em tiles de escolha bem projetados e diferenciados: conectividade, desempenho, armazenamento, áudio/vídeo e erro de aplicativo. Usar dados existentes/catálogo, sem duplicar títulos ou inventar funções. Cada tile tem ícone SVG consistente, índice, título e hint.
- Mostrar um lembrete de segurança útil, como “Primeiro eu verifico. Nada muda sem sua autorização”, se permanecer estritamente fiel ao fluxo real.
- Acesso ao onboarding fácil de perceber, porém secundário.

### 2. Onboarding — `pages/onboarding.ts`

- Percurso de passos elegante com progresso/índice atual, mantendo todas as etapas e a navegação anterior/seguinte.
- Ilustração acolhedora só na abertura/conclusão se ajudar; a etapa de capacidades vs limites deve ser muito legível e equilibrada.
- Consentimentos opcionais grandes, claros e desmarcados por padrão; autonomia como opções comparáveis, sem padrão agressivo; componente `app-ai-connect` preservado.
- Não afirmar que o computador foi verificado ao concluir onboarding.

### 3. Diagnóstico — `pages/diagnosis.ts`

- A inspeção deve parecer trilha de verificação e não uma lista genérica. Estado por probe, sinais explícitos, etapa em andamento e explicações.
- Não fabricar porcentagens/progresso. Sem eventos parciais, usar indicador indeterminado honesto.
- Manter “Nada está sendo alterado agora”, botão Parar, e estados de leitor de tela.
- No resultado, separar evidência, interpretação e confiança. Sugestão alternativa da IA precisa continuar uma sugestão, e a mudança de caminho só acontece com clique explícito.
- Erros têm tratamento visual distinto e dizem que nada foi alterado.

### 4. Plano — `pages/plan.ts`

- Etapas numeradas, ação com linguagem simples, risco e forma de desfazer em layout fácil de comparar. Elevação de privilégio explícita quando pertinente.
- Área “O que não será tocado” visível sem promessas maiores que o núcleo garante.
- Preservar modo de escolher apenas algumas etapas, estado busy, validação de seleção não vazia e navegação de recusa.
- O CTA principal do caminho real comunica revisão/aprovação, não execução antecipada.

### 5. Aprovação — `pages/approval.ts`

- Janela separada compacta e séria: explicar o que será feito e reiterar “Nada acontece sem o seu Sim”.
- Nenhuma etapa pré-selecionada. Risco, reversão e necessidade de elevação legíveis. Validade do plano permanece informada.
- Preservar rigorosamente `APPROVAL_ARM_MS`, `armed()`, rearm ao ganhar foco/visibilidade, `chosen`, aprovação no backend/core e a janela separada. Não remover ou contornar guardas de segurança por estética.
- Ações “Não, obrigado” e “Sim, pode fazer” claramente diferenciadas; CTA primária só habilita quando regras existentes permitem.
- Nada de mascote, gamificação ou efeito visual que pressione o usuário a aprovar.

### 6. Resultado — `pages/result.ts`

- Desenvolver layouts distintos para progresso, erro, verificação, confirmação pessoal, correção indisponível, falta de elevação e não resolvido.
- Selo “CONFERIDO” só em resultado realmente sustentado. Distinguir “conferi e parece resolvido” da confirmação pessoal “Sim, voltou”.
- Caminhos de relatório e retorno devem ser fáceis de achar; nada de afirmar sucesso se o core não afirmou.

### 7. Histórico — `pages/history.ts`

- Apresentar como registro/timeline editorial; título da família, data, status e último gatilho. Status sempre com palavra, não só cor.
- Empty state tem intenção visual e CTA para começar, sem inventar métricas/estatísticas.

### 8. Meu computador — `pages/computer.ts`

- Ficha técnica com rótulos legíveis, valores monoespaçados, divisores e hierarquia.
- Só renderizar campos que a API fornece. Não expor hostname, nome de usuário, serial ou outros dados proibidos.
- Privacidade clara mas discreta.

### 9. Configurações — `pages/settings.ts`

- Agrupar Privacidade, Autonomia, Inteligência artificial e Sobre num sistema de seções; cada uma deve ser navegável e escaneável.
- Consentimentos permanecem opcionais e não marcados por padrão. Componente de IA preserva seus estados atuais.
- “Apagar tudo” é destrutivo e distinto, exige confirmação clara, Cancelar e confirmação final. Manter lógica, exportação e feedback.
- Não inventar estatísticas, telemetria, auto update ou opção ainda não implementada.

### 10. Relatório — `pages/report.ts`

- Dar à prévia uma aparência editorial de relatório técnico imprimível, sem substituir textarea real e editável por imagem.
- Organizar “contém / não contém”, entrada editável, gerar, copiar e salvar. Todos os fluxos atuais e mensagens continuam funcionais.
- Deixar claro que usuário decide a quem entregar e que o app não envia esse relatório.

### 11. Ajuda — `pages/help.ts`

- Transformar os blocos em guia prático bem hierarquizado, com índice/âncoras se fizer sentido, ilustração limitada e texto confortável.
- Capacidades, limites, IA opcional e quando pedir ajuda humana permanecem fiéis à documentação.

### 12. Estados e componentes comuns

Cobrir estados de carregamento, vazio, erro, indisponível, selecionado, hover, foco, disabled e sucesso. Botão primário vermelho-sinal; secundário contornado; destrutivo visualmente separado. Ícones SVG consistentes e acessíveis. Não remover semântica, rótulos, mensagens ou qualquer affordance existente.

## ARQUIVOS E ASSETS DA IDENTIDADE

- Coloque a ilustração selecionada em `apps/desktop/ui/public/branding/assistente-oficina.png` (ou caminho público coerente com a convenção do repo). Não adicionar assets enormes redundantes. Se copiar SVGs de motivo, só usar os que forem visualmente necessários.
- A prancha de referência não precisa entrar no bundle do app. Ela pode ficar sob `branding/references/` como documentação, desde que seu tamanho não vá ao bundle final.
- Ajuste `branding/manifest-assets.json` com status e propósito verdadeiros. Não alegar que o app usa um asset se não usa.
- Manter logotipos existentes; não criar um logo novo em CSS nem redesenhar o símbolo sem motivo concreto.
- Atualizar `branding/tokens.json`, `branding/tokens.css`, `apps/desktop/ui/src/styles.css`, `.claude/skills/helpmydesk-visual-identity/SKILL.md` e qualquer docs de marca que crie para que a identidade sobreviva a futuras sessões de agentes. Remover do skill regras antigas que impeçam esta evolução, mas manter invariantes de segurança, acesso e performance.
- Se criar `IDENTIDADE-VISUAL.md`, `HANDOFF-COMPLETO.md`, `COMPONENTES-E-TELAS.md` ou `PROMPT-IMPLEMENTACAO.md` dentro do repo, preencher com o sistema realmente implementado, não uma intenção futura. Marcar as áreas que ainda não foram implementadas.

## RESTRIÇÕES QUE NÃO PODEM SER VIOLADAS

- Não alterar lógica de Rust, regras de política, executor, IPC, catálogo, `capabilities/`, controles de elevação, `APPROVAL_ARM_MS`, validação de aprovação ou kill switch.
- Não adicionar controle remoto, execução arbitrária, função de diagnóstico ou correção não existente.
- Não mudar garantias de privacidade ou fazer afirmações sobre dados que não são confirmadas por código.
- Não criar progressos fake, dados fake em produção, gráficos de métricas sem dados ou estados falsos de “online/seguro/atualizado”.
- Não pedir autorização do usuário para cada melhoria visual ordinária; implemente as melhorias dentro do escopo. Se encontrar conflito real com constituição/regra de segurança, pare apenas aquela mudança, explique-a e prossiga com o restante.
- Preserve os textos `Protótipo` nas situações mock e diferencie demos de execução real.
- Nenhuma dependência nova sem versão exata, verificação de licença, justificativa e alternativa documentadas.

## PROCESSO DE TRABALHO

### Fase A — inspeção focada (curta)
Mapeie shell, páginas, tokens, testes e arquivo de skill. Identifique padrões quebrados e contratos funcionais para preservar. Não produza um relatório final de auditoria nesta fase.

### Fase B — implementação
Implemente nesta ordem:
1. Tokens e shell sidebar/workspace, com tema claro/escuro e breakpoints.
2. Componentes globais e linguagem de ícones/motivos.
3. Início — a tela que deve estabelecer a marca.
4. Diagnóstico, plano, aprovação e resultado — garantir segurança e clareza.
5. Onboarding, histórico, computador, configurações, relatório e ajuda.
6. Ajustes de estados, empty/error/loading e acessibilidade.
7. Atualizar assets, manifest, skill e manual de marca.

A ordem pode ser ajustada por dependências, mas o resultado deve abranger **todas as telas existentes** e não apenas o Início.

### Fase C — revisão real
- Rodar a UI quando o ambiente permitir; capturar telas pelo menos de Início, diagnóstico, plano/aprovação, resultado, configurações e um estado vazio/erro. Comparar tema claro e escuro e uma janela estreita.
- Inspecionar visualmente recortes, alinhamento, overflow, contraste, cards aninhados, densidade, navegação ativa, controles longos e comportamento de zoom/tamanho de texto.
- Corrigir as falhas encontradas em vez de só listá-las.

### Fase D — validação
Rodar no diretório correto:
```bash
cd apps/desktop/ui
npx ng test --watch=false
npx prettier --check "src/**/*.{ts,html,css}"
npx ng build
cd ../../..
git diff --check
```
Rode `tools/check-all.sh` se o ambiente/tempo permitir e se não exigir ações externas inesperadas. Se for possível inspecionar `package.json`/lockfile e instalar dependências com o fluxo do projeto, faça-o sem modificar versões arbitrariamente. Não introduza rede nos testes.

## CRITÉRIOS DE ACEITAÇÃO / DEFINIÇÃO DE PRONTO

- A tela inicial deixa de parecer template simples; a personalidade do HelpMyDesk é reconhecível sem depender só do logo.
- A shell tem navegação desktop própria e layout responsivo.
- Todas as telas atuais foram revisadas e implementadas, não apenas documentadas.
- Tema escuro, tema claro e tamanho de texto funcionam; foco teclado, estados e redução de movimento permanecem.
- Fluxos, labels, routes, status e ações continuam funcionando; nenhuma regressão de negócio foi introduzida.
- Design tokens e skill/manifest/manual estão sincronizados com o que foi realmente feito.
- Build, testes e formatting executados; problemas corrigidos ou listados com evidência.
- A resposta final é objetiva e contém: resumo do visual novo, lista de arquivos principais alterados, assets, telas concluídas, comandos rodados e resultado real, limitações que restaram e screenshots/capturas se geradas.

**Comece agora. Inspecione, implemente o redesenho e valide. Não pare na auditoria nem me devolva somente outro plano.**
