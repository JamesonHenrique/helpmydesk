# HelpMyDesk — Identidade visual v2 (proposta de refinamento)

**Nome da direção:** Oficina editorial de precisão  
**Tagline mantida:** “Seu computador, sem mistério.”  
**Personalidade:** acessível, engenhosa, transparente, cuidadosa, com energia visual e sem estética corporativa genérica.

## 1. O que a marca deve fazer sentir

O HelpMyDesk é uma pequena oficina que explica antes de tocar. Não deve parecer painel de administração empresarial, antivírus ameaçador, brinquedo infantil nem chatbot genérico. A marca combina:

- **Editorial:** hierarquia tipográfica clara, títulos expressivos, legendas técnicas, notas laterais e páginas com ritmo.
- **Oficina:** marcações de inspeção, trilhas, parafusos/pontos, selos de conferência, camadas de papel e sinais de reparo.
- **Precisão:** etapas numeradas, evidência, estado explícito, confiança calibrada, antes/depois somente quando houver dados reais.
- **Humanidade:** linguagem simples, mascote em pontos de acolhimento e explicação sem infantilizar o usuário.

A assinatura emocional da interface é “curiosa, competente e honesta”, não “olha como sou inteligente”.

## 2. Manter o DNA; ampliar o vocabulário

A versão 1 já fixa bons fundamentos: papel quente, carvão, coral, vermelho-sinal, verde-lima como ponto de verificação, textura pontilhada e sombra editorial dura. A versão 2 não apaga esses elementos. Ela os organiza e dá a eles mais funções:

- Fundo principal de papel (`#F3F0E6`) para áreas de leitura e identidade.
- Superfície de conteúdo (`#FFFCF5`) em painéis de foco.
- Carvão (`#22282D`) para estrutura, navegação, diagramas e texto principal.
- Vermelho-sinal (`#B73825`) como ação primária, seleção forte e marcação crítica.
- Coral (`#FF6C4D`) como detalhe de ilustração/brand, não como texto miúdo sobre papel.
- Verde-lima (`#D8F16A`) reservado: seleção ativa, passo verificado, foco visual de alto destaque. Não pintar a UI inteira de lima.
- Verde técnico/azul-petróleo (`#496965`, proposta nova) como tinta secundária para trilhas, diagramas e metadados. Se adotado, cadastrar em `branding/tokens.json`, `branding/tokens.css` e `apps/desktop/ui/src/styles.css`, além da variante escura, e validar contraste. Não usar como texto de baixo contraste.
- Textos secundários devem continuar legíveis; jamais sacrificar contraste por “cara editorial”.

Não adicionar gradientes violeta/azul de SaaS, neon espalhado, sombras difusas em excesso ou cartões arredondados idênticos em toda parte. A identidade vem do contraste de materiais, do layout e das marcações funcionais — não de colocar mais cores.

## 3. Composição da aplicação

### Shell desktop

- Transformar a área de trabalho em layout de desktop com **barra lateral persistente** de navegação e workspace principal amplo. A largura máxima atual de `52rem` pode ser mantida apenas para blocos longos de leitura, não como limite de toda a aplicação.
- Sidebar com aproximadamente 224–248 px em telas desktop: símbolo da marca e nome, grupo “Atendimento” (Início, Histórico), grupo “Computador” (Meu computador), grupo “Preferências” (Configurações, Ajuda), e área inferior com estado/privacidade real.
- Seleção do menu: fundo carvão ou superfície escura, uma barra/colchete coral e um pequeno marcador lima apenas no item ativo. Não usar todos os itens como botões-card.
- No topo do workspace: breadcrumb/título contextual e área de estado se houver estado real a representar. Evitar múltiplas barras de navegação duplicadas.
- A área principal precisa de respiro e ritmo: cabeçalho editorial, conteúdo, ações no rodapé da seção e notas/contexto secundário em coluna lateral quando fizer sentido.
- Desktop-first, mas responsivo. Em janelas estreitas, sidebar vira faixa compacta/hamburger acessível ou navegação adaptada. Nunca cortar conteúdo horizontalmente.

### Sistema de painéis

Variar o modo de apresentação conforme a finalidade, em vez de usar `.card` para tudo:

1. **Panel editorial:** superfície clara, linha sólida de 1 px e sombra curta de 2–3 px; conteúdo importante.
2. **Ficha técnica:** fundo inset, tipografia monoespaçada para valores, divisores e números.
3. **Painel de estado:** faixa lateral colorida + rótulo e explicação; cor sempre acompanhada de ícone/palavra.
4. **Tile de escolha:** número de índice, ícone próprio, título, explicação de uma linha e estado hover/foco preciso.
5. **Faixa de segurança:** carvão ou verde técnico suave, com texto explicando exatamente o que vai acontecer ou não.
6. **Selo / anotação:** uso pontual, nunca repetido em todas as caixas.

Evitar o efeito “um cartão dentro de outro cartão dentro de outro cartão”. Usar divisores, fundos alternados, títulos de seção e layout assimétrico para organizar.

## 4. Tipografia

- Preservar a stack de sistema para desempenho e funcionamento offline. Não depender de Google Fonts/CDN em runtime.
- Títulos: system sans forte, peso 750–850, tracking discretamente negativo; escala generosa e alinhamento limpo.
- Corpo: stack atual, peso regular, line-height de 1.5–1.6 e largura de linha legível.
- Dados, identificadores, índices, horário e rótulos pequenos: monoespaçada atual, com uso pontual.
- Criar hierarquia perceptível por peso, escala e espaçamento, não por fazer todo texto cinza e pequeno.
- Manter o controle de tamanho de texto `A− / A+`, que altera `--font-size`; não fixar `html { font-size }` sem respeitar esse token.
- Texto de usuário em português simples. Legendas técnicas curtas podem existir, mas sempre subordinadas a uma explicação humana.

Escala sugerida (ajustável ao runtime): display de abertura `clamp(2rem, 3.2vw, 3.25rem)`, título de tela `clamp(1.7rem, 2.6vw, 2.35rem)`, seção `1.15–1.35rem`, corpo a partir de `1rem` e auxiliares nunca abaixo de `0.8125rem` sem justificativa de acessibilidade.

## 5. Linguagem gráfica própria

Usar de forma intencional:

- Linhas de circuito/trilhas de diagnóstico como recurso de fundo de baixa opacidade.
- Marcas de inspeção: índice `01`, `02`, `03`, ticks, pequenos nós de ligação, setas e notas de bancada.
- Selos de conferência somente em resultados realmente verificados; nunca antecipar sucesso.
- Textura pontilhada de baixa densidade em áreas grandes, sem competir com texto.
- Ilustração do assistente-oficina somente no início, onboarding e eventualmente em vazio/ajuda. Não colocar um robô em cada tile ou em todas as telas.
- Ícones desenhados em SVG inline com o mesmo stroke e caixa óptica; sem emoji como substituto de ícone funcional. Não introduzir biblioteca de ícones apenas por conveniência sem justificar dependência/licença.
- Pequenos blocos monoespaçados com nomes como `INSPEÇÃO`, `ETAPA 02`, `RESULTADO CONFERIDO`, sempre complementares ao português normal.

Não usar a prancha gerada como captura de tela, background integral ou source de textos: é apenas referência atmosférica.

## 6. Movimento e feedback

- Microinterações curtas de 100–180 ms para foco, hover, seleção e expansão; easing discreto.
- Evitar flutuação contínua do mascote, animações de fundo e loading cinematográfico.
- Se a operação não fornece progresso parcial real, mostrar estado indeterminado com texto honesto — nada de percentuais fabricados.
- Respeitar `prefers-reduced-motion: reduce`.
- Estados de carregamento, erro, vazio, sucesso e “não disponível” precisam ter layouts completos e diferentes, sem depender só da cor.

## 7. Segurança como parte da identidade

O visual deve aumentar compreensão e controle, não disfarçar limites:

- Antes de uma ação: mostrar o que será feito, risco, reversão e o que não será tocado.
- Nunca transformar a autorização em uma CTA ambígua.
- Nada pré-selecionado na tela de aprovação; manter sua janela separada, delay/arming, escopo e expiração atuais.
- A verificação técnica e a percepção do usuário são coisas diferentes; o UI não deve declarar “resolvido” se a evidência do sistema só sustenta “parece resolvido”.
- Manter os avisos do protótipo e não fingir que uma ação foi executada quando se usa mock.
- O estado de IA é opcional e não pode virar um bloqueio visual para o fluxo básico.

## 8. Tema escuro

Tratar o escuro como uma identidade completa, não como filtro invertido:

- Fundo carvão profundo; superfícies em degraus de carvão; papel claro em texto principal.
- Coral claro para ações, verde-lima somente para foco/verificação, verde técnico claro para diagramas.
- Reduzir opacidade de texturas e trilhas para não poluir áreas escuras.
- Testar borders, inputs, estados de erro, foco, seleção, hover e controles nativos nos dois temas.
- Preservar `prefers-color-scheme` e `data-theme` existentes.

## 9. Orçamento de performance

- Preferir CSS, SVG inline/arquivos pequenos e PNG transparente de tamanho moderado.
- Não introduzir vídeo, canvas animado, imagens de fundo enormes, biblioteca gráfica ou novas dependências desnecessárias.
- Usar ilustração principal no máximo em áreas pequenas e importantes; ela deve ter dimensão responsiva e não provocar layout shift.
- Não usar fontes remotas. Não criar textura com filtros/caríssimos em todos os componentes.

## 10. Tom de voz da interface

Voz: direta, humana, calma, transparente e responsável. Preferir:
- “Vou verificar sem mudar nada.”
- “Encontrei um sinal de problema.”
- “Isto é o que proponho fazer.”
- “Você decide se quer continuar.”
- “Conferi no sistema. Para você, voltou a funcionar?”

Evitar:
- “IA avançada resolveu automaticamente” sem evidência.
- “100% seguro”, “garantido”, “milagroso” ou certeza indevida.
- Jargão não explicado, tom infantil ou culpa do usuário.
