# Assets do kit e recomendações de uso

## `assets/illustrations/assistente-oficina.png`
Ilustração original preparada para este kit, com transparência. Usos sugeridos: hero da tela inicial, primeiro passo do onboarding, vazio da Ajuda. Não usar como background full bleed; não posicionar atrás de textos críticos; não usar para sugerir que o assistente é uma pessoa ou que a IA executou algo. Se a imagem não se integrar ao estilo final implementado, o agente pode omitir o asset da UI — mas deve registrar a decisão e continuar a usar os demais recursos de identidade.

## `assets/references/prancha-direcao-visual.png`
Prancha conceitual de direção visual gerada para este trabalho. Serve para transmitir materiais, composição e hierarquia. Os textos da imagem são ilustrativos e podem conter erros; reconstruir toda UI em componentes verdadeiros.

## `assets/brand/*.svg`
Cópias dos arquivos de logo que já existiam no repositório fornecido. São arquivos de referência/conveniência, não versões novas do logo.

## `assets/motifs/*.svg`
Motivos vetoriais decorativos originais: trilhas, selo e textura. Aplicar com opacidade e apenas quando ajudar a leitura. `selo-conferido.svg` só pode ser exibido em estado que realmente tenha verificação concluída.

## Performance
O aplicativo deve seguir funcional offline. Não carregar as imagens de URLs externas, não adicionar fontes remotas e não incluir a prancha conceitual no bundle final se ela só servir como documentação. Os PNGs devem ser carregados apenas nas telas que precisam deles.
