# Critérios de aceitação — refinamento visual HelpMyDesk

## Experiência visual

- [ ] Em janela desktop, a interface lê como um aplicativo de suporte proprietário, não como uma página web genérica centrada.
- [ ] Navegação lateral e workspace ampliam a hierarquia sem duplicar barras de navegação.
- [ ] A tela inicial tem uma âncora visual de marca, composição tipográfica expressiva e cinco formas de começar identificáveis.
- [ ] Há variação entre painel editorial, ficha técnica, status, lista, tile de escolha e faixa de segurança; não é tudo o mesmo `.card`.
- [ ] Coral/vermelho e verde-lima têm funções específicas e não inundam toda a interface.
- [ ] Ícones, numerais, trilhas e selos compõem uma linguagem consistente.
- [ ] Tema claro e escuro parecem deliberados e completos.
- [ ] A UI é responsiva em janela ampla, média e estreita, sem scroll horizontal inesperado.

## Usabilidade e acessibilidade

- [ ] Todas as ações funcionam por teclado; o indicador `:focus-visible` é forte e não removido.
- [ ] Contraste de texto e controles é revisado nos dois temas (objetivo WCAG 2.2 AA).
- [ ] Nenhum estado é codificado apenas por cor.
- [ ] Leitores de tela recebem as mensagens de status/erro existentes (`aria-live`, `role=alert` conforme aplicável).
- [ ] O controle de texto A−/A+ continua funcionando e seus tokens não são sobrepostos por `html { font-size }` fixo.
- [ ] `prefers-reduced-motion: reduce` desativa efeitos não essenciais.
- [ ] Conteúdo e controles não dependem da imagem gerada; alt/aria decorativo é aplicado corretamente.

## Verdade do produto e segurança

- [ ] Não foi alterada a lógica da API, diagnóstico, política, executor, IPC, Tauri capability ou catálogo para obter o visual.
- [ ] Não há progresso, ticket, telemetria, sistema detectado ou verificação inventados.
- [ ] O modo protótipo continua identificado e não afirma executar verificações/correções reais.
- [ ] Consentimentos continuam opcionais e desmarcados por padrão.
- [ ] A janela de aprovação é independente; nenhuma etapa vem pré-selecionada; delay/arming e validade são preservados.
- [ ] “Resolvido”, “verificado” e confirmação pessoal continuam estados distintos.
- [ ] Ações destrutivas continuam com confirmação clara e possibilidade de cancelar antes de apagar.

## Integridade técnica

- [ ] `apps/desktop/ui/src/styles.css`, `branding/tokens.css`, `branding/tokens.json`, manifest e skill da marca foram reconciliados.
- [ ] Mudanças de identidade refletem-se em `.claude/skills/helpmydesk-visual-identity/SKILL.md`; tokens operacionais e de referência têm correspondência.
- [ ] Não foi adicionada biblioteca/dependência sem necessidade, versão fixa, licença e justificativa.
- [ ] Testes de UI rodam; Prettier check e Angular build rodam.
- [ ] `git diff --check` passa.
- [ ] O agente informa com precisão todo teste que não pôde executar e por quê.
- [ ] Relatório final lista arquivos alterados, assets adicionados, telas concluídas, validações e pendências reais.
