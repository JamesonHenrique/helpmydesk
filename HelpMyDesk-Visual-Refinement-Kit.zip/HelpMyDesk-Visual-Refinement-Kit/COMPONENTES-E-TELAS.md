# Especificação de componentes e telas — HelpMyDesk

Este documento diz ao agente o que deve mudar visualmente e o que precisa permanecer funcional. Rotas e nomes correspondem ao snapshot inspecionado; se o workspace real divergir, confirme os arquivos antes de editar.

## 1. Shell global (`app.html`, `app.css`, `styles.css`)

- Reestruturar header horizontal como **sidebar + workspace** no desktop. Usar links Angular `routerLink`, `routerLinkActive` e `ariaCurrentWhenActive` existentes, preservando navegação por teclado e foco.
- Navegação agrupada: **ATENDIMENTO** — Início, Histórico; **COMPUTADOR** — Meu computador; **PREFERÊNCIAS** — Configurações, Ajuda. Onboarding fica como fluxo de entrada, não precisa ser item fixo do menu.
- Área inferior da sidebar: tagline ou “Seu computador, sem mistério.” e lembrete de privacidade apenas com a mesma promessa verdadeira já presente no produto; não inventar estado online, versão atualizada ou integridade do sistema.
- Workspace: barra superior discreta, breadcrumb opcional, título/descrição como conteúdo principal; permitir maior largura que os atuais 52rem. Páginas com texto longo ainda devem ter largura legível.
- Indicador `Protótipo: ...` deve ser visível e não virar um banner enorme; preservar o texto de que nada é verificado nem alterado quando usa mock.
- Ajustar breakpoints: >= 1100 px sidebar ampla; 760–1099 sidebar compacta sem perder nomes via tooltip/accessible label; <760 navegação compacta/responsiva sem overflow. Breakpoints finais conforme inspeção e teste.
- Não codificar logos duplicados se os SVGs da marca já podem ser reutilizados; alinhar o símbolo que está hardcoded no shell com `branding/brand-mark.svg` se o arquivo for apropriado.

## 2. Início (`/` — `pages/home.ts`)

Objetivo: primeira tela memorável e extremamente clara.

- Hero assimétrico: título grande mantendo sentido de “O que está acontecendo?”, texto de apoio humano, uma ilustração do assistente-oficina no lado direito/alto e pequenas trilhas técnicas de baixa opacidade. Não usar o mascote como elemento interativo falso.
- Campo “Escreva com suas palavras” como ação central; manter `maxlength`, estado disabled quando IA não conectada, preview do que é enviado, busy/loading, question, error e todos os limites de privacidade existentes.
- O modo básico precisa receber o mesmo peso visual: quando a IA estiver desconectada, explicar de modo digno e mostrar primeiro as cinco formas de começar. Não mostrar CTA de texto como habilitada quando o input está disabled.
- As cinco famílias do catálogo devem virar tiles com pequenas ilustrações/icons SVG consistentes e índices: conectividade, desempenho, armazenamento, áudio/vídeo e erro de aplicativo. Usar exatamente os códigos/títulos/hints vindos dos dados — não duplicar ou hardcode novos diagnósticos.
- Tile: ícone com cor limitada, índice técnico pequeno, título expressivo e hint em português. Composição assimétrica controlada (um tile em destaque pode existir, mas sem sugerir prioridade clínica/técnica inexistente).
- Barra/nota de confiança: “Primeiro eu verifico. Nada muda sem sua autorização.” Somente se o texto corresponder ao comportamento atual.
- Link do onboarding menos escondido que um rodapé sem hierarquia, mas sem disputar o CTA.

## 3. Onboarding (`/boas-vindas` — `pages/onboarding.ts`)

- Transformar os seis passos em percurso visual com trilho de progresso e numeração clara, mantendo passo atual e total.
- Etapa inicial usa ilustração como acolhimento, título humano e uma composição editorial assimétrica.
- Etapa “o que faço/o que não faço” separa capacidades e limites com duas áreas distintas e legíveis; não esconder os limites num bloco visual secundário.
- Consentimentos opcionais: cartões compactos com área clicável grande, estados checked/focus visíveis, explicação do que se autoriza e sem pré-seleção nova.
- Autonomia: opções como lista comparável/fieldset com rótulos, sem assumir o nível mais alto.
- Integração IA: manter componente `app-ai-connect`, estados e conteúdo já existentes.
- Último passo: selo de conclusão somente como conclusão do onboarding, não como verificação do computador.

## 4. Diagnóstico (`/diagnostico/:family` — `pages/diagnosis.ts`)

- Durante a verificação, usar uma trilha vertical numerada/lista de checks. Cada item com estado explícito. Não inventar progresso real ou percentuais: se não há evento de progresso, mostrar indeterminado.
- Deixar claro no primeiro plano: “Nada está sendo alterado agora.” Manter botão Parar e estados de leitor de tela (`aria-live`).
- Em erro, layout de recuperação com o que aconteceu, “Nada foi alterado” e próximos caminhos; aparência distinta do sucesso.
- No resultado, separar “O que as verificações encontraram” (evidência) da “Explicação” (interpretação). Mostrar confiança usando o texto definido no catálogo; não converter incerteza em certeza.
- Sugestão divergente da IA deve ficar contextualizada: indicar que é sugestão e só mudar de caminho mediante o botão existente. Preservar explicação precisa do que foi enviado à IA.
- Os seletores de resultado e sistema do protótipo dentro de `<details>` continuam claramente marcados como protótipo, sem aparecer como função normal.

## 5. Plano (`/plano/:family` — `pages/plan.ts`)

- Apresentar as etapas numeradas com: ação em palavras simples, risco, como desfazer, necessidade de elevação se houver.
- Uma coluna de explicação pode ser acompanhada de faixa lateral “O que não será tocado” — preservar o texto atual e não prometer mais do que o núcleo garante.
- Alternância “Escolher só algumas” precisa transformar a lista num modo de seleção claro; manter `chosen`, estado `busy` e a condição que impede aprovar zero etapas.
- CTA principal deve comunicar “Revisar e aprovar” no fluxo real; não escrever “executando” antes de a ação ser aprovada. O protótipo pode manter rótulos identificados como protótipo.
- Link para voltar/recusar continua secundário mas facilmente achável.

## 6. Aprovação (`/aprovacao/:ticket/:plan` — `pages/approval.ts`)

Esta é tela de segurança: clareza antes de decoração.

- Layout mais compacto e independente, apropriado à janela separada do Tauri.
- Cabeçalho: “Aprovar correção” e “Nada acontece sem o seu Sim”.
- Itens têm checkbox sem pré-seleção, ação, risco, reversão e mensagem de elevação quando necessário.
- Plano/hash/validade permanecem informados, sem fazer o hash ocupar o foco visual.
- Botão “Sim, pode fazer” permanece disabled até `armed()` e uma ou mais etapas selecionadas. Não remover nem contornar o delay de 1000 ms, o rearm em foco/visibilidade, a janela separada ou a consulta ao plano validado pelo core.
- “Não, obrigado” visível e sem cor parecida com CTA primária.
- Não usar a ilustração do robô como elemento de confiança na janela de aprovação; priorizar informação explícita.

## 7. Resultado (`/resultado/:family` — `pages/result.ts`)

- Distinguir: execução em andamento, erro, verificado, confirmação do usuário, correção indisponível, elevação indisponível e não resolvido.
- Selo visual de “CONFERIDO” só no estado comprovado; se a verificação só disser “parece resolvido”, usar essa frase, sem proclamar certeza.
- Separar evidência da confirmação humana (“Para você também voltou a funcionar?”) e manter botões “Ainda não” e “Sim, voltou”.
- Nos erros: tom calmo, o que não foi alterado e caminho para relatório.
- Não esconder ações úteis em ícones sem rótulo.

## 8. Histórico (`/historico` — `pages/history.ts`)

- Lista como timeline/registro editorial, mais informativa que cartões genéricos repetidos.
- Destacar título da família, data, estado e último gatilho, todos a partir dos dados reais.
- Estados incluem aberto, em andamento, esperando usuário, resolvido, não resolvido, reaberto, cancelado, sem resposta e encerrado. Não use só cor: sempre mostrar o rótulo.
- Estado vazio com ilustração simplificada (preferir motif SVG, não necessariamente o mascote completo), texto acolhedor e ação de iniciar atendimento.
- Não inventar estatística de tickets, taxa de sucesso, economia de tempo ou pontuação.

## 9. Meu computador (`/meu-computador` — `pages/computer.ts`)

- Layout de ficha técnica: rótulos na primeira coluna, valores em segunda coluna monoespaçada, separadores e subtítulos claros.
- Mostrar estado de leitura e campos que realmente são fornecidos pela API; não acrescentar serial, usuário, hostname ou dados que o projeto deliberadamente não mostra.
- A promessa de não mostrar/guardar nome do computador/usuário continua visível, mas sem virar um bloco de marketing enorme.

## 10. Configurações (`/configuracoes` — `pages/settings.ts`)

- Organizar por áreas com subtítulos / índice: Privacidade, Autonomia, Inteligência artificial, Sobre.
- Distinguir configurações reversíveis de ação destrutiva “Apagar tudo”.
- Consentimentos opcionais têm texto explicativo, estado e contexto; nenhum consentimento novo é concedido por padrão.
- A ação de apagar precisa de confirmação textual legível, Cancelar e botão destrutivo. Manter os mesmos métodos, estado `confirming`, exportação e mensagens.
- O componente `app-ai-connect` mantém a lógica e apresenta estados de conexão reais.
- A ficha “Sobre” utiliza apenas os campos existentes; sem claim de release ou atualização automática além do texto real.

## 11. Relatório (`/relatorio` — `pages/report.ts`)

- Prévia com aparência de relatório técnico imprimível, mas acessível em tela: sumário visual “inclui / não inclui”, área editável espaçosa, monoespaçada só onde agrega.
- Preservar `maxlength`, geração, edição, cópia, salvamento, status e fluxo que encaminha ao início quando ainda não há diagnóstico.
- A visualização pode parecer um documento, mas precisa continuar sendo um textarea real editável; não transformar a saída em imagem.
- Reforçar que o usuário decide se e para quem vai entregar, sem criar envio em rede.

## 12. Ajuda (`/ajuda` — `pages/help.ts`)

- Layout tipo guia de oficina: índice de seção simples, títulos claros, blocos de texto sem excesso de caixa, ilustrações de apoio em 1–2 lugares.
- Manter as capacidades/limites e explicação do modo básico/IA sem prometer função ainda não existente.
- Não usar mascote/marketing em excesso para esconder texto de segurança.

## 13. Componentes transversais

- Botões: primário vermelho-sinal, secundário superfície clara/contorno, destrutivo separado; foco teclado evidente; estados hover/active/disabled consistentes.
- Campos: área clicável apropriada, hint/label sempre vinculados, borda visible, placeholder não substitui label.
- Badges: usar somente para estado ou metadado realmente útil; não transformar cada número em pill.
- Erro/sucesso/aviso: cor + ícone/label + frase humana.
- Ícones: um único vocabulário de SVG inline; preservar aria-hidden em decoração, aria-label em botões de ícone e nomes acessíveis em navegação compacta.
- Sem nova dependência visual salvo justificativa forte. Não remover `axe-core`, testes, atributos semânticos ou o modo de tema.
