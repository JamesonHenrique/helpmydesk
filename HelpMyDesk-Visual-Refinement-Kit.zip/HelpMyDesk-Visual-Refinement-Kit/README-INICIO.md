# HelpMyDesk — Kit de refinamento visual

Este pacote foi preparado após examinar o snapshot do repositório `JamesonHenrique/helpmydesk` enviado nesta conversa e a versão pública do README. Ele não altera automaticamente seu projeto: contém a direção de arte, as especificações e o prompt de execução para o OpenCode aplicar as mudanças de verdade.

## Comece por aqui

1. Abra `PROMPT-MESTRE-OPENCODE.md` e envie seu conteúdo ao OpenCode **com o repositório HelpMyDesk aberto como workspace**.
2. Deixe os documentos deste kit disponíveis ao agente (copie a pasta para a raiz do repositório, por exemplo em `docs/branding/visual-refinement-kit/`, ou anexe os arquivos ao contexto do agente).
3. O prompt pede implementação, não apenas auditoria: a expectativa é editar o Angular/CSS/telas, atualizar a documentação da marca e rodar verificações.
4. A imagem `assets/references/prancha-direcao-visual.png` é uma referência de atmosfera e composição, não um arquivo de tela pronto para ser exibido no app.
5. `assets/illustrations/assistente-oficina.png` é uma ilustração de apoio com transparência. Use com parcimônia (principalmente na tela inicial e/ou onboarding), sem substituir controles reais por uma imagem.

## O que contém

- `PROMPT-MESTRE-OPENCODE.md` — instruções de implementação completas e objetivas.
- `IDENTIDADE-VISUAL-V2.md` — direção criativa, narrativa de marca, cor, tipografia, layout e movimento.
- `COMPONENTES-E-TELAS.md` — especificação concreta para shell e todas as telas/estados presentes.
- `CRITERIOS-DE-ACEITACAO.md` — checklist de qualidade visual, comportamento, segurança e testes.
- `TOKENS-DIRECAO-V2.json` — proposta semântica de tokens para orientar a reconciliação; não substituir a fonte operacional cegamente.
- `assets/brand/` — cópias dos três logos que já existem no repositório enviado.
- `assets/illustrations/assistente-oficina.png` — ilustração original gerada para apoiar a identidade.
- `assets/references/prancha-direcao-visual.png` — moodboard conceitual, somente referência.
- `assets/motifs/` — motivos SVG originais (trilhas de diagnóstico, selo e textura) para uso decorativo opcional.

## Restrições relevantes encontradas no projeto

- Stack de UI: Angular 22 sobre Tauri v2; núcleo de produto em Rust.
- Fonte operacional atual da identidade: `apps/desktop/ui/src/styles.css`.
- Tokens de referência que devem permanecer sincronizados: `branding/tokens.json` e `branding/tokens.css`.
- As regras atuais da marca também estão em `.claude/skills/helpmydesk-visual-identity/SKILL.md`; atualize-a no mesmo trabalho para não deixar instruções antigas anularem a nova direção.
- Não mexer em regras de negócio, IPC, executor, política, catálogo, segurança, capacidades do Tauri ou fluxo de aprovação só para “facilitar” o visual.
- Não declarar que build/teste passou se não tiver executado.

## Importante sobre a imagem de referência

O gerador de imagens pode desenhar texto técnico com erros. Por isso, a prancha serve somente para comunicar contraste, composição, materiais gráficos e hierarquia. Todos os textos, controles, ícones funcionais, estados e layouts reais devem ser construídos em Angular/HTML/CSS e continuar acessíveis.
